vim.g.loaded_autopairs = 0
