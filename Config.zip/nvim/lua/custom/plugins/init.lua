return {
    {
        "windwp/nvim-autopairs",
        enabled = false,
    },
}

