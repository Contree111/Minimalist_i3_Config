return {
  "aditya-azad/candle-grey",
  name = "candle-grey",
  lazy = true,
  config = function()
        vim.cmd.colorscheme("candle-grey")
  end,
}
