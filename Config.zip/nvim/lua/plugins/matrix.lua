return {
    "iruzo/matrix-nvim",
    init = function ()
        vim.cmd("colorscheme matrix")
    end
}
